Instructions d'installation :
1. Double-cliquez sur install.command
2. Suivez les instructions à l'écran.